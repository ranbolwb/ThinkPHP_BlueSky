-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2015-06-14 04:55:40
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bluesky`
--

-- --------------------------------------------------------

--
-- 表的结构 `think_auth_group`
--

CREATE TABLE IF NOT EXISTS `think_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` char(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `think_auth_group_access`
--

CREATE TABLE IF NOT EXISTS `think_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `think_auth_rule`
--

CREATE TABLE IF NOT EXISTS `think_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `condition` char(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `think_menu`
--

CREATE TABLE IF NOT EXISTS `think_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL,
  `code` varchar(20) NOT NULL,
  `url` varchar(100) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `think_menu`
--

INSERT INTO `think_menu` (`id`, `title`, `code`, `url`, `state`) VALUES
(1, '系统管理', '01', '', 1),
(2, '系统配置', '0101', '../System/index', 1),
(3, '用户管理', '0102', '../System/user', 1),
(4, '订单管理', '02', '', 1),
(5, '订单流转', '0201', '../safd', 1),
(6, '订单录入', '020101', '../System/user', 1),
(7, '订单审核', '020102', '../System/index', 1);

-- --------------------------------------------------------

--
-- 表的结构 `think_role`
--

CREATE TABLE IF NOT EXISTS `think_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `super` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `think_role`
--

INSERT INTO `think_role` (`id`, `name`, `super`) VALUES
(1, '超级管理员', 1),
(2, '人事经理', 0);

-- --------------------------------------------------------

--
-- 表的结构 `think_role_menu`
--

CREATE TABLE IF NOT EXISTS `think_role_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleid` int(11) NOT NULL,
  `menuid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `think_role_menu`
--

INSERT INTO `think_role_menu` (`id`, `roleid`, `menuid`) VALUES
(1, 2, 4),
(2, 2, 5),
(3, 2, 6),
(4, 2, 7);

-- --------------------------------------------------------

--
-- 表的结构 `think_user`
--

CREATE TABLE IF NOT EXISTS `think_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `truename` varchar(30) NOT NULL,
  `score` int(11) NOT NULL DEFAULT '0',
  `createtime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lasttime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nickname` (`nickname`,`email`,`mobile`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `think_user`
--

INSERT INTO `think_user` (`id`, `nickname`, `email`, `mobile`, `password`, `truename`, `score`, `createtime`, `lasttime`, `state`) VALUES
(1, 'admin', 'admin@bluesky.com', '13800138000', '123456', '管理员', 0, '2015-06-04 20:56:59', '2015-06-14 02:13:42', 1),
(2, 'lucy', 'lucy@bluesky.com', '13800138001', '123456', '露茜', 0, '2015-06-13 20:19:34', '2015-06-14 02:08:40', 1);

-- --------------------------------------------------------

--
-- 表的结构 `think_user_login`
--

CREATE TABLE IF NOT EXISTS `think_user_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `logintime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=95 ;

--
-- 转存表中的数据 `think_user_login`
--

INSERT INTO `think_user_login` (`id`, `uid`, `ip`, `logintime`) VALUES
(18, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(19, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(20, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(21, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(22, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(23, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(24, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(25, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(26, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(27, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(28, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(29, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(30, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(31, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(32, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(33, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(34, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(35, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(36, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(37, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(38, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(39, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(40, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(41, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(42, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(43, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(44, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(45, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(46, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(47, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(48, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(49, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(50, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(51, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(52, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(53, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(54, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(55, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(56, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(57, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(58, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(59, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(60, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(61, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(62, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(63, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(64, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(65, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(66, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(67, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(68, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(69, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(70, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(71, 1, '0.0.0.0', '2015-06-05 00:00:35'),
(72, 1, '0.0.0.0', '2015-06-12 19:20:52'),
(73, 1, '0.0.0.0', '2015-06-13 13:22:54'),
(74, 1, '0.0.0.0', '2015-06-13 13:23:29'),
(75, 1, '0.0.0.0', '2015-06-13 13:33:57'),
(76, 1, '0.0.0.0', '2015-06-13 13:37:08'),
(77, 1, '0.0.0.0', '2015-06-13 13:37:17'),
(78, 1, '0.0.0.0', '2015-06-13 15:25:03'),
(79, 1, '0.0.0.0', '2015-06-13 15:27:08'),
(80, 1, '0.0.0.0', '2015-06-13 15:27:37'),
(81, 2, '0.0.0.0', '2015-06-13 20:31:13'),
(82, 1, '0.0.0.0', '2015-06-13 20:38:34'),
(83, 2, '0.0.0.0', '2015-06-13 20:38:48'),
(84, 1, '0.0.0.0', '2015-06-13 21:10:38'),
(85, 2, '0.0.0.0', '2015-06-13 21:10:44'),
(86, 2, '0.0.0.0', '2015-06-13 21:10:57'),
(87, 2, '0.0.0.0', '2015-06-13 21:11:40'),
(88, 1, '0.0.0.0', '2015-06-13 21:11:54'),
(89, 2, '0.0.0.0', '2015-06-13 21:12:16'),
(90, 2, '0.0.0.0', '2015-06-13 21:13:20'),
(91, 2, '0.0.0.0', '2015-06-13 21:13:33'),
(92, 1, '0.0.0.0', '2015-06-14 02:06:32'),
(93, 2, '0.0.0.0', '2015-06-14 02:08:40'),
(94, 1, '0.0.0.0', '2015-06-14 02:13:42');

-- --------------------------------------------------------

--
-- 表的结构 `think_user_role`
--

CREATE TABLE IF NOT EXISTS `think_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `roleid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `think_user_role`
--

INSERT INTO `think_user_role` (`id`, `userid`, `roleid`) VALUES
(1, 1, 1),
(2, 2, 2);

--
-- 限制导出的表
--

--
-- 限制表 `think_user_login`
--
ALTER TABLE `think_user_login`
  ADD CONSTRAINT `think_user_login_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `think_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
